package com.sineth.sabi;

import android.app.Activity;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private MediaPlayer player;
    private Button playButton;
    private AudioManager audioManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        setMediaVolumeToMaximum();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(32, 32, 32, 32);
        root.setBackgroundColor(Color.rgb(8, 11, 18));

        TextView title = new TextView(this);
        title.setText("SABI");
        title.setTextColor(Color.WHITE);
        title.setTextSize(38);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, android.graphics.Typeface.BOLD);

        TextView subtitle = new TextView(this);
        subtitle.setText("AUTO AUDIO PLAYER");
        subtitle.setTextColor(Color.rgb(0, 200, 255));
        subtitle.setTextSize(13);
        subtitle.setGravity(Gravity.CENTER);

        TextView status = new TextView(this);
        status.setText("Your audio is playing • Loop ON • Volume MAX");
        status.setTextColor(Color.LTGRAY);
        status.setTextSize(14);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 36, 0, 28);

        playButton = new Button(this);
        playButton.setText("PAUSE");
        playButton.setOnClickListener(v -> togglePlayback());

        root.addView(title);
        root.addView(subtitle);
        root.addView(status);
        root.addView(playButton);
        setContentView(root);

        player = MediaPlayer.create(this, R.raw.sabi_audio);
        if (player != null) {
            player.setLooping(true);
            player.setVolume(1.0f, 1.0f);
            player.start();
        } else {
            status.setText("Could not load audio file.");
        }
    }

    private void setMediaVolumeToMaximum() {
        if (audioManager != null) {
            int max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, max, 0);
        }
    }

    private void togglePlayback() {
        if (player == null) return;
        if (player.isPlaying()) {
            player.pause();
            playButton.setText("PLAY");
        } else {
            setMediaVolumeToMaximum();
            player.start();
            playButton.setText("PAUSE");
        }
    }

    @Override
    protected void onDestroy() {
        if (player != null) {
            if (player.isPlaying()) player.stop();
            player.release();
            player = null;
        }
        super.onDestroy();
    }
}
