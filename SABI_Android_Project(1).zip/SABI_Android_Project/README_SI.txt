SABI Android App Project

මෙම project එකේ ඔබ upload කළ MP3 audio එක ඇතුළත් කර ඇත.

Features:
- App එක open කළ විට audio auto-play වේ.
- Phone එකේ MEDIA volume එක උපරිමයට සකසයි.
- Audio එක loop වේ.
- Play / Pause button එක ඇත.

APK build කිරීම:
1. Android Studio එකෙන් මෙම SABI folder එක open කරන්න.
2. Gradle sync සම්පූර්ණ වීමට ඉඩ දෙන්න.
3. Build > Build Bundle(s) / APK(s) > Build APK(s) තෝරන්න.
4. APK එක app/build/outputs/apk/debug/app-debug.apk තුළ ලැබේ.

Requirements:
- Android SDK Platform 35
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- JDK 17

සටහන:
Android system එකේ media volume එක app එක open කරන විට maximum කරයි.
මෙය phone speaker/headphone hardware සීමාව ඉක්මවා ශබ්දය වැඩි නොකරයි.

GitHub හරහා APK build කිරීම (Android phone එකෙන් කළ හැක):
1. මෙම ZIP එක extract කරන්න.
2. GitHub එකේ අලුත් repository එකක් සාදන්න (උදා: SABI).
3. Project එකේ සියලුම files repository එකට upload කර commit කරන්න.
4. Repository එකේ Actions tab එකට යන්න.
5. "Build SABI APK" workflow එක තෝරා Run workflow ඔබන්න.
6. Build එක සාර්ථක වූ පසු SABI-APK artifact එක download කරන්න.
7. ZIP artifact එක extract කර app-debug.apk install කරන්න.

මෙම project එක source project එකකි; මෙහි සූදානම් APK binary එකක් අඩංගු නොවේ.
